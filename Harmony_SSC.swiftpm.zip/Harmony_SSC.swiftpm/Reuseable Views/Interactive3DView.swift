import SwiftUI
import SceneKit

struct Interactive3DView: View {
    
    var fileName: String
    
    var body: some View {
        HStack(alignment: .center) {
            SceneView(scene: {
                let scene = SCNScene(named: fileName)!
                scene.background.contents = UIColor(named: "blue2")
                
                let rotateAction = SCNAction.rotateBy(x: 0, y: 2 * CGFloat.pi, z: 0, duration: 24)
                let foreverRotate = SCNAction.repeatForever(rotateAction)
//
//                let scaleAction = SCNAction.scale(to: 1.0, duration: 3)
//                let foreverScale = SCNAction.repeatForever(scaleAction)
                
                let sequence = SCNAction.group([foreverRotate])
                scene.rootNode.runAction(sequence)
                return scene
            }(), options: [.autoenablesDefaultLighting,])
            .shadow(radius: 10)
            .background{
                RoundedRectangle(cornerRadius: 10)
            }
            .padding()
        }
    }
}

//
//  MainButtons.swift
//  Harmony_SSC
//
//  Created by Shivacharan Reddy on 24/02/24.
//

import SwiftUI

struct MainButtons: View {
    
    var title: String
    @State var selected: Bool = false
    
    var body: some View {
        Button(action: {
            print(title)
            selected.toggle()
        }, label: {
            Text(title)
                .font(.system(size: 40, weight: .semibold, design: .default))
                .foregroundStyle(Color(.blue3))
                .background {
                    RoundedRectangle(cornerRadius: 10)
                        .fill(Color(.blueHeading))
                        .frame(width: 225, height: 75)
                        .shadow(color: .white, radius: 7)
                        .shadow(color: Color(.blueHeading), radius: 5)
                        
                }
                .frame(width: 225, height: 75)
                
        })
    }
}

#Preview {
    MainButtons(title: "Test")
}

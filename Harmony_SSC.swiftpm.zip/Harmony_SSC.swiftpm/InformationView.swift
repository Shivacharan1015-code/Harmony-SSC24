//
//  InformationView.swift
//  Harmony_SSC
//
//  Created by Shivacharan Reddy on 24/02/24.
//

import SwiftUI

struct InformationView: View, InformationCardDelegate {
    
    @Environment(\.dismiss) private var dismiss
    
    @State var index = 0
    let titles = ["Our Home", "Our Challenge", "Our Contribution"]
    
    @State var backgroundColor1 = Color(.blue1)
    @State var backgroundColor2 = Color(.blue2)
    @State var backgroundColor3 = Color(.blue3)
    
    @State var textHeadingDark = Color(.blueHeading)
    @State var textHeadingLight = Color(.blueHeadingii)
        
    var body: some View {
        ZStack {
            LinearGradient(colors: [backgroundColor1, backgroundColor2, backgroundColor3], startPoint: .leading, endPoint: .trailing)
            
            VStack {
                ZStack {
                    HStack {
                        Button {
                            dismiss()
                        } label: {
                            Circle()
                                .frame(width: 55)
                                .foregroundColor(textHeadingDark)
                                .overlay {
                                    Image(systemName: "chevron.left")
                                        .tint(backgroundColor3)
                                }
                        }
                        Spacer()
                    }
                    .padding()
                    
                    Text(titles[index])
                        .font(.system(size: 60, weight: .bold, design: .default))
                        .foregroundStyle(LinearGradient(colors: [textHeadingLight, textHeadingDark], startPoint: .leading, endPoint: .trailing))
                        .contentTransition(.numericText())
                        .padding()
                }
                
                InformationCardView(informationCardDelegate: self, color3: $backgroundColor3, textHeading: $textHeadingDark)
            }
            .padding()
        }
        .ignoresSafeArea()
        .navigationBarHidden(true)
        .navigationTitle("")
        .statusBarHidden()
    }
    
    func newIndex(index: Int) {
        self.index = index
        
        if index == 0 {
            withAnimation {
                backgroundColor1 = Color(.blue1)
                backgroundColor2 = Color(.blue2)
                backgroundColor3 = Color(.blue3)
                
                textHeadingDark = Color(.blueHeading)
                textHeadingLight = Color(.blueHeadingii)
            }
        } else if index == 1 {
            withAnimation {
                backgroundColor1 = Color(.red1)
                backgroundColor2 = Color(.red2)
                backgroundColor3 = Color(.red3)
                
                textHeadingDark = Color(.redHeading)
                textHeadingLight = Color(.redHeadingii)
            }
        } else {
            withAnimation {
                backgroundColor1 = Color(.green1)
                backgroundColor2 = Color(.green2)
                backgroundColor3 = Color(.green3)
                
                textHeadingDark = Color(.greenHeading)
                textHeadingLight = Color(.greenHeadingii)
            }
        }
    }
}

struct InformationCardView: View {
    
    @State var informationCardDelegate: InformationCardDelegate
    
    @State var shadow1: CGFloat = 10.0
    @State var shadow2: CGFloat = 0.0
    @State var shadow3: CGFloat = 0.0
    @State var shadow4: CGFloat = 0.0
    
    @State var index = 0
    @State var selectedIndex = 0
    
    @Binding var color3: Color
    @Binding var textHeading: Color
    
    let earthImages = ["forest", "soil", "water", "fire"]
    let earthTitles = ["Trees", "Soil", "Water", "Fire"]
    let earthDescriptions = ["""
                            Trees offer many environmental benefits.
                            
                            Trees reduce the urban heat island effect through evaporative cooling and reducing the amount of sunlight that reaches parking lots and buildings.
                            
                            Trees improve our air quality by filtering harmful dust and pollutants such as ozone, carbon monoxide, and sulfur dioxide from the air we breathe.
                            
                            Trees give off oxygen that we need to breathe.
                            
                            Trees reduce the amount of storm water runoff, which reduces erosion and pollution in our waterways and may reduce the effects of flooding.
                            
                            Many species of wildlife depend on trees for habitat. Trees provide food, protection, and homes for many birds and mammals.
                            """,
                             """
Soil carries out a range of functions and services without which human life would not be possible.

It provides an environment for plants (including food crops and timber wood) to grow in, by anchoring roots and storing nutrients.

It filters and cleans our water and helps prevent natural hazards such as flooding.

It contains immense levels of biodiversity.

Finally, it is the largest terrestrial store of carbon, and therefore helps to regulate the climate.
""",
                             """
Water covers more than 70 % of Earth’s surface. 

It was in water that life on Earth started, so it is not surprising that all living things on our blue planet need water. Water is in fact many things: it is a vital need, a home, a local and global resource, a transport corridor and a climate regulator.
""",
                             """
Fire is a natural phenomenon, and nature has evolved with its presence.

Many ecosystems benefit from periodic fires, because they clear out dead organic material—and some plant and animal populations require the benefits fire brings to survive and reproduce.
"""
    ]
    
    let challengeImages = ["deforestation", "pollution", "plastic", "ewaste"]
    let challengeTitles = ["Deforestation", "Pollution", "Plastic", "E-Waste"]
    let challengeDescription = ["""
The loss of trees and other vegetation can cause climate change, desertification, soil erosion, fewer crops, flooding, increased greenhouse gases in the atmosphere, and a host of problems for Indigenous people.

Effects of Deforestation

- Loss of habitat

- Increased Greenhouse Gases

- Water in the Atmosphere

- Soil Erosion and Flooding
""",
    """
Air pollution refers to the release of harmful contaminants into the earth’s atmosphere. These contaminants are quite detrimental and in some cases, pose serious health issues.

Water pollution is said to occur when toxic pollutants and particulate matter are introduced into water bodies such as lakes, rivers and seas.

Soil pollution, also called soil contamination, refers to the degradation of land due to the presence of chemicals or other man-made substances in the soil. The xenobiotic substances alter the natural composition of soil and affect it negatively.
""",
    """
Plastic is a major contributor to both land and water pollution.

Plastic production emits greenhouse gases, which contribute to climate change. Climate change is a major threat to both humans and wildlife.

Plastic contains harmful chemicals that can leach into food and water. These chemicals have been linked to cancer, reproductive problems, and other health issues.
""",
    """
E-waste is the fastest growing solid waste stream in the world.

The soil in the region surrounding of e-waste could get contaminated because of large levels of lead and mercury in those materials.

Heating e-waste which results in the discharge of toxic compounds such as lead, cadmium and beryllium into the air.
"""]
    
    let helpImages = ["reuse", "conserve", "sustainable", "plant"]
    let helpTitles = ["Reduce, Reuse, Recycle", "Conserve Energy", "Sustainable Practices", "Plant Trees"]
    let helpDescription = ["""
Embrace a lifestyle of reducing waste by using reusable items, recycling materials like paper, plastic, and glass, and minimizing single-use products. Proper waste disposal helps curb pollution and conserves resources.
""",
    """
Make energy-conscious choices by using energy-efficient appliances, turning off lights and electronic devices when not in use, and considering alternative energy sources like solar power. Reducing energy consumption contributes to lower greenhouse gas emissions.
""",
    """
Make informed consumer choices by supporting businesses and products that prioritize sustainable and environmentally friendly practices. This includes choosing products with minimal packaging, opting for eco-friendly alternatives, and being mindful of the environmental impact of your purchases.
""",
    """
Contribute to reforestation efforts by planting trees in your local community. Participate in or support conservation initiatives that aim to protect natural habitats, wildlife, and biodiversity. Engaging in such activities helps restore ecosystems and mitigate the impacts of deforestation.
"""]
    
    var body: some View {
        Rectangle()
            .foregroundColor(.clear)
            .padding()
            .overlay {
                GeometryReader(content: { geometry in
                    HStack {
                        Button {
                            if index > 0 {
                                withAnimation {
                                    index -= 1
                                    informationCardDelegate.newIndex(index: index)
                                }
                            }
                        } label: {
                            Circle()
                                .frame(width: 50)
                                .foregroundColor(textHeading)
                                .overlay {
                                    Image(systemName: "chevron.left")
                                        .tint(index == 0 ? .gray : color3)
                                }
                        }
                        .padding()
                        VStack {
                            Text("Select a card")
                                .italic()
                                .foregroundStyle(.black)
                            HStack {
                                Rectangle()
                                    .foregroundColor(.clear)
                                    .background {
                                        Image(getImage(mainIndex: index, localIndex: 0))
                                            .resizable()
                                            .aspectRatio(contentMode: .fill)
                                    }
                                    .clipped()
                                    .padding(5)
                                    .shadow(radius: shadow1)
                                    .scaleEffect(shadow1 == 10 ? 1.01 : 1)
                                    .onTapGesture {
                                        withAnimation {
                                            selectedIndex = 0
                                            shadow1 = 10
                                            shadow2 = 0
                                            shadow3 = 0
                                            shadow4 = 0
                                        }
                                    }
                                Rectangle()
                                    .foregroundColor(.clear)
                                    .background {
                                        Image(getImage(mainIndex: index, localIndex: 1))
                                            .resizable()
                                            .aspectRatio(contentMode: .fill)
                                    }
                                    .clipped()
                                    .padding(5)
                                    .shadow(radius: shadow2)
                                    .scaleEffect(shadow2 == 10 ? 1.01 : 1)
                                    .onTapGesture {
                                        withAnimation {
                                            selectedIndex = 1
                                            shadow1 = 0
                                            shadow2 = 10
                                            shadow3 = 0
                                            shadow4 = 0
                                        }
                                    }
                            }
                            HStack {
                                Rectangle()
                                    .foregroundColor(.clear)
                                    .background {
                                        Image(getImage(mainIndex: index, localIndex: 2))
                                            .resizable()
                                            .aspectRatio(contentMode: .fill)
                                    }
                                    .clipped()
                                    .padding(5)
                                    .shadow(radius: shadow3)
                                    .scaleEffect(shadow3 == 10 ? 1.01 : 1)
                                    .onTapGesture {
                                        withAnimation {
                                            selectedIndex = 2
                                            shadow1 = 0
                                            shadow2 = 0
                                            shadow3 = 10
                                            shadow4 = 0
                                        }
                                    }
                                Rectangle()
                                    .foregroundColor(.clear)
                                    .background {
                                        Image(getImage(mainIndex: index, localIndex: 3))
                                            .resizable()
                                            .aspectRatio(contentMode: .fill)
                                    }
                                    .clipped()
                                    .padding(5)
                                    .shadow(radius: shadow4)
                                    .scaleEffect(shadow4 == 10 ? 1.01 : 1)
                                    .onTapGesture {
                                        withAnimation {
                                            selectedIndex = 3
                                            shadow1 = 0
                                            shadow2 = 0
                                            shadow3 = 0
                                            shadow4 = 10
                                        }
                                    }
                            }
                        }
                        .frame(width: geometry.size.width * 0.55)
                        Rectangle()
                            .foregroundColor(.clear)
                            .padding(5)
                            .overlay {
                                VStack {
                                    Text(getTitle(mainIndex: index, localIndex: selectedIndex))
                                        .font(.title)
                                        .fontWeight(.bold)
                                        .foregroundStyle(.black)
                                        .contentTransition(.numericText())
                                    
                                    Divider()
                                    
                                    ScrollView {
                                        VStack {
                                            Text(getDescription(mainIndex: index, localIndex: selectedIndex))
                                                .font(.body)
                                                .fontWeight(.regular)
                                                .foregroundStyle(.black)
                                                .padding(.bottom, 20)
                                            
                                            Text("Source: Internet")
                                                .font(.callout)
                                                .italic()
                                                .foregroundStyle(.black)
                                        }
                                    }
                                }
                            }
                        
                        Button {
                            if index < 2 {
                                withAnimation {
                                    index += 1
                                    informationCardDelegate.newIndex(index: index)
                                }
                            }
                        } label: {
                            Circle()
                                .frame(width: 50)
                                .foregroundColor(textHeading)
                                .overlay {
                                    Image(systemName: "chevron.right")
                                        .tint(index == 2 ? .gray : color3)
                                }
                        }
                        .padding()
                    }
                })
            }
    }
    
    func getImage(mainIndex: Int, localIndex: Int) -> String {
        
        if mainIndex == 0 {
            return earthImages[localIndex]
        } else if mainIndex == 1 {
            return challengeImages[localIndex]
        } else {
            return helpImages[localIndex]
        }
    }
    
    func getTitle(mainIndex: Int, localIndex: Int) -> String {
        
        if mainIndex == 0 {
            return earthTitles[localIndex]
        } else if mainIndex == 1 {
            return challengeTitles[localIndex]
        } else {
            return helpTitles[localIndex]
        }
    }
    
    func getDescription(mainIndex: Int, localIndex: Int) -> String {
        
        if mainIndex == 0 {
            return earthDescriptions[localIndex]
        } else if mainIndex == 1 {
            return challengeDescription[localIndex]
        } else {
            return helpDescription[localIndex]
        }
    }
}

#Preview {
    InformationView()
}

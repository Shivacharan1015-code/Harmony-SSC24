import SwiftUI
import AVKit

@main
struct MyApp: App {
    
    @Environment(\.scenePhase) var scenePhase
    
    @State var audioPlayer: AVAudioPlayer!
    let sound = Bundle.main.path(forResource: "paperback", ofType: "mp3")
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .onAppear {
                    self.audioPlayer = try! AVAudioPlayer(contentsOf: URL(fileURLWithPath: sound!))
                    if !self.audioPlayer.isPlaying {
                        self.audioPlayer.play()
                    }
                }
                .onChange(of: scenePhase) { newValue in
                    if newValue == .background {
                        self.audioPlayer.pause()
                    } else if newValue == .active {
                        self.audioPlayer.play()
                    }
                }
        }
    }
}

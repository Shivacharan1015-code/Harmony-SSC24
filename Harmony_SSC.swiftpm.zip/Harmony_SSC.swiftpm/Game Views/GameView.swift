//
//  GameView.swift
//  Harmony_SSC
//
//  Created by Shivacharan Reddy on 24/02/24.
//

import SwiftUI
import SpriteKit

struct GameView: View, GameCommunicationDelegate, TimerViewDelegate {
    
    
    let deleteConformation = ViewToGameDelegate.shared
    let buildingInformation = ["hospital" : "Provides Healthcare and work to the people of your city, removing it will affect the happiness of your city",
                               "town_hall" : "Town Hall is one of the most important buildings of your city, ensure that at least 1/2 is present",
                               "shop" : "A shop is a daily essential for your people, ensure a sufficient number of them are present in your city",
                               "bank" : "A bank ensures financial security of your city, a vital need for the well-being of any community",
                               "library" : "A quite place for the intellectual who one day might propose expectional concepts for the well-being of the community, it is important to encourage such citizens in your city",
                               "post_office" : "Takes care of communication, ensure at least 1/2 of them are present in your city",
                               "school" : "Education for the leaders of tomorrow, a much needed building for any city",
                               "house" : "Shelter to a family of 5 people, ensure that you dont remove to many homes from your city",
                               "appartment" : "Houses 40 people, ensure that you have sufficient housing properties in your city"]
    
    @Environment(\.dismiss) private var dismiss
    
    @State var timeLimit: Int
    var gameHardnes: CGFloat
    var minimumLimit: Int
    
    @State var gameStats: GameInformation?
    @State var population = 0
    @State var happinies = 65
    @State var harmony = 0
    @State var initialPopulation = 0
    
    @State var selectedName = "Select building"
    
    @State var gameComplete = false
    @State var gameWon = false
    @State var reasonForLoss = ""
    @State var quit = "End Game"
    @State var quitC = 0
    @State var timePassed = 0
        
    var body: some View {
        
        GeometryReader(content: { geometry in
            HStack {
                playScene(gameHardnes: gameHardnes, delegateConformation: self).equatable()
                    .frame(width: geometry.size.width * 0.8, height: geometry.size.height, alignment: .leading)
                
                VStack {
                    
                    TimerView(delegate: self, timeLimit: timeLimit)
                    
                    VStack {
                        Text("Population: \(population) (>\(Int(Double(initialPopulation) * 0.75)))")
                            .contentTransition(.numericText())
                            .padding([.top, .bottom], 5)
                        Text("Happiness: \(happinies)% (>50%)")
                            .contentTransition(.numericText())
                            .padding([.top, .bottom], 5)
                        Text("Harmony: \(harmony)% (~50%)")
                            .contentTransition(.numericText())
                            .padding([.top, .bottom], 5)
                        
                        Divider()
                    }
                    
                    VStack {
                        Image(selectedName)
                            .resizable()
                            .scaledToFit()
                            .frame(maxHeight: geometry.size.width * 0.17)
                        Text(selectedName.capitalized)
                            .font(.title)
                            .minimumScaleFactor(0.6)
                        
                        ScrollView {
                            Text(buildingInformation[selectedName] ?? "")
                                .font(.body)
                        }
                        
                        Text("Replace")
                            .lineLimit(2)
                            .font(.system(size: 30, weight: .semibold, design: .default))
                            .foregroundStyle(Color(.blue3))
                            .background {
                                RoundedRectangle(cornerRadius: 10)
                                    .fill(Color(.blueHeading))
                                    .frame(width: geometry.size.width * 0.17, height: 65)
                            }
                            .frame(width: geometry.size.width * 0.18, height: 45)
                            .padding()
                            .onTapGesture {
                                deleteConformation.delete = true
                            }
                        
                        Divider()
                    }
                    .animation(.spring(response: 0.5, dampingFraction: 0.4, blendDuration: 0.4), value: selectedName)
                    
                    Spacer()
                    
                    Text(quit)
                        .font(.system(size: 30, weight: .semibold, design: .default))
                        .foregroundStyle(Color(.red3))
                        .background {
                            RoundedRectangle(cornerRadius: 10)
                                .fill(Color(.redHeading))
                                .frame(width: geometry.size.width * 0.17, height: 65)
                                
                        }
                        .frame(width: geometry.size.width * 0.17, height: 45)
                        .padding()
                        .onTapGesture {
                            if quitC == 0 {
                                quitC += 1
                                quit = "Sure?"
                            } else {
                                quitC = 0
                                quit = "End Game"
                                dismiss()
                            }
                            
                        }
                }
                .preferredColorScheme(.dark)
                .padding()
                .frame(width: geometry.size.width * 0.2, height: geometry.size.height)
            }
        })
        .fullScreenCover(isPresented: $gameComplete, onDismiss: {
            dismiss()
        }, content: {
            GameCompleteView(gameResult: $gameWon, population: population, happines: happinies, harmony: harmony, reasonForLoss: $reasonForLoss, timeTaken: $timePassed, gameMode: $timeLimit)
        })
        .navigationTitle("Game")
        .navigationBarHidden(true)
        .statusBarHidden()
        .ignoresSafeArea()
    }
    
//    func setUpScene(size: CGSize) -> SKScene {
//        print(gameHardnes)
//        var scene: SKScene {
//            let scene = GameScene(size: CGSize(width: size.width * 0.8, height: size.height), horizontalBlocks: gameHardnes)
//            scene.scaleMode = .resizeFill
//            scene.communication = self
//            return scene
//        }
//        return scene
//    }
    
    func updateStats(current: GameInformation, progressUpdata: Bool) { // logic to be checked
        print(current)
        quit = "End Game"
        quitC = 0
        gameStats = current
        withAnimation {
            population = (current.appartments * 40) + (current.house2 * 5)
        }
        if population > initialPopulation {
            initialPopulation = population
        }
        
        if !progressUpdata {
            return
        }
        
        if population < Int(Double(initialPopulation) * 0.75) {
            withAnimation {
                happinies -= 3
                harmony -= 1
            }
        } else if current.bank < minimumLimit || current.hospital < minimumLimit || current.libriary < minimumLimit || current.post_office < minimumLimit || current.school < minimumLimit || current.shop < minimumLimit || current.town_hall < minimumLimit {
            withAnimation {
                happinies -= 5
            }
        } else if current.bank < (minimumLimit + 1) || current.hospital < (minimumLimit + 1) || current.libriary < (minimumLimit + 1) || current.post_office < (minimumLimit + 1) || current.school < (minimumLimit + 1) || current.shop < (minimumLimit + 1) || current.town_hall < (minimumLimit + 1) {
            withAnimation {
                happinies -= 1
            }
        } else if current.tree.isMultiple(of: minimumLimit + 2) {
            withAnimation {
                happinies += 1
            }
        }
        
        withAnimation {
            harmony += minimumLimit == 1 ? 2 : 1
        }
        
        if minimumLimit == 1 && current.tree > 18 {
            withAnimation {
                harmony += 4
            }
        } else if current.tree > 20 {
            harmony += 2
        }
        
        checkForGameStatus()
    }
    
    func selectedNode(name: String) {
        quit = "End Game"
        quitC = 0
        selectedName = name
    }
    
    func checkForGameStatus() {
        if gameComplete {
            return
        }
        if population < Int(Double(initialPopulation) * 0.5) {
            // game lost
            reasonForLoss = "population"
            gameWon = false
            gameComplete = true
        } else if happinies < 50 {
            reasonForLoss = "happy"
            gameWon = false
            gameComplete = true
        }
        if happinies >= 50 && harmony > 50 {
            // game won
            gameComplete = true
            gameWon = true
        }
    }
    
    func updateTime(timePassed: Int) {
        
        if gameComplete {
           return
        }
        self.timePassed = timePassed
    }
    
    func timeOver() {
        if reasonForLoss == "time" {
            return
        }
        if harmony >= 50 && happinies >= 50 {
            gameWon = true
            gameComplete = true
        } else {
            reasonForLoss = "time"
            gameWon = false
            gameComplete = true
        }
    }
}

struct TimerView: View {
    
    let delegate: TimerViewDelegate
    
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    
    @State var timeLimit: Int
    @State var timePassed = 0
    
    var body: some View {
        VStack {
            Text("\(timeLimit)")
                .onReceive(timer, perform: { _ in
                    if timeLimit > 0 {
                        withAnimation {
                            timeLimit -= 1
                            timePassed += 1
                            delegate.updateTime(timePassed: timePassed)
                            
                        }
                    } else {
                        delegate.timeOver()
                    }
                })
                .foregroundColor(timeLimit < 11 ? .red : .white)
                .contentTransition(.numericText())
                .font(.system(size: 40, weight: .bold, design: .rounded))
                .padding([.top, .leading, .trailing])
            
            Text("Seconds Remaining")
            
            Divider()
        }
    }
}

struct playScene: View, Equatable {
    
    let gameHardnes: CGFloat
    let delegateConformation: GameView
    
    @State var first = 0
    
    var body: some View {
        GeometryReader { geometry in
            SpriteView(scene: setUpScene(size: geometry.size))
        }
    }
    
    func setUpScene(size: CGSize) -> SKScene {
        print(gameHardnes)
        var scene: SKScene {
            let scene = GameScene(size: CGSize(width: size.width, height: size.height), horizontalBlocks: gameHardnes)
            scene.scaleMode = .resizeFill
            scene.communication = delegateConformation
            return scene
        }
        return scene
    }
    
    static func == (lhs: playScene, rhs: playScene) -> Bool {
        // << return yes on view properties which identifies that the
        // view is equal and should not be refreshed (ie. `body` is not rebuilt)
        if lhs.first == 0 {
            lhs.first += 1
            return true
        } else {
            return false
        }
        
    }
}



#Preview {
    GameView(timeLimit: 75, gameHardnes: 31.0, minimumLimit: 1)
}

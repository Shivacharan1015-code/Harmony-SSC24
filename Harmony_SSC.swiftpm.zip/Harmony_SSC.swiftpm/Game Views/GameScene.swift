//
//  GameScene.swift
//  Harmony1
//
//  Created by Shivacharan Reddy on 13/02/24.
//

import SpriteKit
import GameplayKit
import SwiftUI

struct BuildingDimension {
    let widthMultiplier: Int
    let heightMultiplier: Int
    let name: String
}

class GameScene: SKScene {
    
    var communication: GameCommunicationDelegate?
        
    enum SpriteNames: String {
        case bank = "bank"
        case appartment = "appartment"
        case hospital = "hospital"
        case house2 = "house"
        case library = "library"
        case post_office = "post_office"
        case school = "school"
        case shop = "shop"
        case town_hall = "town_hall"
    }
    
    private var numberOfCars = 0
    private var banks = 0
    private var appartment = 0
    private var hospital = 0
    private var house1 = 0
    private var house2 = 0
    private var library = 0
    private var post_office = 0
    private var school = 0
    private var shop = 0
    private var town_hall = 0
    
    private var environmentLoaded = true
    private var gameTime = 0.0
    private var tileSize: CGFloat = -1
    private var verticalBlocks: Int = 0
    private let horizontalBlocks: CGFloat
    private var heightGap: CGFloat = 0
    private let widthGap = 25.0
    private var middlePoint: CGFloat = 0
    private var roadCount = 0
    private var naturalElements = 0
    
    private var moveSelectedNode: SKSpriteNode?
    
    @ObservedObject var deleteConfirmed = ViewToGameDelegate.shared
    
    init(size: CGSize, horizontalBlocks: CGFloat) {
        self.horizontalBlocks = horizontalBlocks
        super.init(size: size)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func sceneDidLoad() {
        super.sceneDidLoad()

        layGrass()
    }
        
    override func update(_ currentTime: TimeInterval) {
        super.update(currentTime)
        
        gameTime += 1.0
        
        if roadCount >= Int(horizontalBlocks) && gameTime.truncatingRemainder(dividingBy: 240) == 0 {
            placeCar()
            placeCar2()
        }
        
        if deleteConfirmed.delete {
            replaceWithNature(at: moveSelectedNode)
            deleteConfirmed.delete = false
            moveSelectedNode = nil
        }
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        
        guard let lastTouch = touches.first else { return }
        
        let nodes = nodes(at: lastTouch.location(in: self))
        
        for node in nodes {
            if node.name != "grass" && node.name != "road" && node.name != "car" && node.name != "tree" {
                
                if let previousNode = moveSelectedNode {
                    previousNode.color = .clear
                    previousNode.colorBlendFactor = 0.0
                }
                
                guard let node = node as? SKSpriteNode else { return }
                moveSelectedNode = node
                moveSelectedNode?.color = .systemBlue
                moveSelectedNode?.colorBlendFactor = 0.4
                communication?.selectedNode(name: moveSelectedNode?.name ?? "nil")
            }
        }
    }
    
    func replaceWithNature(at node: SKSpriteNode?) {
        
        guard let node = node else { return }
        
        if node.position.y <= ceil(middlePoint) {
            print("Down")
            addTree(at: node.position, size: node.size, down: true)
        } else {
            addTree(at: node.position, size: node.size, down: false)
        }
        naturalElements += 1
        updateStats(deleting: node)
        node.removeFromParent()
    }
    
    func addTree(at point: CGPoint, size: CGSize, down: Bool) {
        let treeNode = SKSpriteNode(imageNamed: ["tree", "tree2", "tree3", "tree4"].randomElement()!)
        treeNode.name = "tree"
        treeNode.zPosition = 2
        if down {
            treeNode.anchorPoint = CGPoint(x: 0, y: 1)
        } else {
            treeNode.anchorPoint = CGPoint(x: 0, y: 0)
        }
        treeNode.position = point
        treeNode.size = size
        addChild(treeNode)
    }
    
    func updateStats(deleting node: SKSpriteNode) {
        
        switch node.name {
        case "bank":
            banks -= 1
        case "appartment":
            appartment -= 1
        case "hospital":
            hospital -= 1
        case "house":
            house2 -= 1
        case "library":
            library -= 1
        case "post_office":
            post_office -= 1
        case "school":
            school -= 1
        case "shop":
            shop -= 1
        case "town_hall":
            town_hall -= 1
        default:
            print("Never")
        }
        
        communication?.updateStats(current: GameInformation(appartments: appartment, bank: banks, hospital: hospital, house2: house2, libriary: library, post_office: post_office, school: school, shop: shop, town_hall: town_hall, tree: naturalElements), progressUpdata: true)
    }
    
//    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
//        super.touchesMoved(touches, with: event)
//
//        guard let lastTouch = touches.first else { return }
//
//        let allNodes = nodes(at: lastTouch.location(in: self))
//
//        for node in allNodes {
//            if node == moveSelectedNode {
//
//                guard let node = node as? SKSpriteNode else { return }
//                node.colorBlendFactor = 0.5
//
//                let otherNodes = nodes(at: node.position)
//                for otherNode in otherNodes {
//                    if otherNode == moveSelectedNode {
//                        continue
//                    }
//                    if otherNode.name != "grass" {
//                        node.color = .red
//                        break
//                    } else {
//                        node.color = .green
//                    }
//                }
//
//                let position = lastTouch.location(in: self)
//                let previousPosition = lastTouch.previousLocation(in: self)
//
//                node.position.x += position.x - previousPosition.x
//                node.position.y += position.y - previousPosition.y
//            }
//        }
//    }
    
    func layGrass() {
        tileSize = (frame.width - (widthGap * 2)) / horizontalBlocks // caculate the size of a single tile block
        heightGap = (frame.height.truncatingRemainder(dividingBy: tileSize)) / 2 // Gap at the top and bottom of the play frame
        verticalBlocks = Int((frame.height - (heightGap * 2)) / tileSize) // number of vertical blocks
        let totalBlocks = horizontalBlocks * CGFloat(verticalBlocks) // total grass tile blocks
        var count = 0 // for proper animation
        
        for (index1,x) in stride(from: frame.minX + 25, to: frame.maxX - 25, by: tileSize).enumerated() {
            for (index2,y) in stride(from: frame.minY + heightGap, to: frame.maxY - heightGap, by: tileSize).enumerated() {
                
                let grass = SKSpriteNode(imageNamed: ["grass2", "grass1"].randomElement()!)
                grass.name = "grass"
                grass.size = CGSize(width: tileSize, height: tileSize)
                grass.zPosition = 0
                grass.alpha = 0.0
                grass.position = CGPoint(x: x + 20, y: y)
                grass.anchorPoint = CGPoint(x: 0, y: 0)
                
                let placeAction = SKAction.moveTo(x: x, duration: 0.2)
                let fadeInAction = SKAction.fadeIn(withDuration: 0.2)
                let placeAndFade = SKAction.group([fadeInAction, placeAction])
                let sequence = SKAction.sequence([SKAction.wait(forDuration: (Double(index1) + Double(index2)) * 0.1), placeAndFade])
                
                grass.run(sequence) {
                    count += 1
                    self.layRoads(currentProgress: count, total: Int(totalBlocks))
                }
                addChild(grass)
            }
        }
    }
            
    func layRoads(currentProgress: Int, total: Int) {
        guard currentProgress == total else { return }
                
        let _middle = Int(verticalBlocks / 2)
        middlePoint = (CGFloat(_middle) * (tileSize) + heightGap)
        
        for (index,x) in stride(from: frame.minX, to: frame.maxX, by: tileSize).enumerated() {
            placeRoad(index: index, x: x, y: middlePoint)
        }
    }

    func placeRoad(index: Int, x: CGFloat, y: CGFloat) {
        let road = SKSpriteNode(imageNamed: "road3")
        road.name = "road"
        road.size = CGSize(width: tileSize, height: tileSize)
        road.anchorPoint = CGPoint(x: 0, y: 0)
        road.zPosition = 1
        road.position = CGPoint(x: x + 20, y: y)
        road.alpha = 0.0
        
        let placeAction = SKAction.moveTo(x: x, duration: 0.1)
        let fadeInAction = SKAction.fadeIn(withDuration: 0.1)
        let placeAndFade = SKAction.group([fadeInAction, placeAction])
        let sequence = SKAction.sequence([SKAction.wait(forDuration: Double(index) * 0.1), placeAndFade])
        
        road.run(sequence) {
            self.roadCount += 1
            self.layTopBuildings(current: self.roadCount)
            self.layBottomBuildings(current: self.roadCount)
        }
        
        addChild(road)
    }
    
    func layTopBuildings(current: Int) {
        
        guard current == Int(horizontalBlocks) else { return }
        var currentY = middlePoint + tileSize
        let remainingX = Int(horizontalBlocks)
        var remainingY = 0
        var buildingNumber = 1
        
        for _ in stride(from: currentY, to: frame.maxY - heightGap, by: tileSize) {
            remainingY += 1
        }
        
        var pointerX = 0
        var pointerY = 0
        
        while ((remainingX - pointerX) > 1) {
            var highX = 0
            pointerY = 0
            currentY = middlePoint + tileSize
            while((remainingY - pointerY) > 1) {
                let randomBuilding = getDimensionsOfRandomBuilding()
                placeBuildings(dimesions: randomBuilding, x: (tileSize * CGFloat(pointerX) + widthGap), y: currentY + (tileSize * CGFloat(pointerY)), down: false, buildingNumber: buildingNumber)
                buildingNumber += 1
                if randomBuilding.widthMultiplier > highX {
                    highX = randomBuilding.widthMultiplier
                }
                pointerY += randomBuilding.heightMultiplier
            }
            pointerX += highX
        }
        
        communication?.updateStats(current: GameInformation(appartments: appartment, bank: banks, hospital: hospital, house2: house2, libriary: library, post_office: post_office, school: school, shop: shop, town_hall: town_hall, tree: naturalElements), progressUpdata: false)
    }
    
    func layBottomBuildings(current: Int) {
        guard current == Int(horizontalBlocks) else { return }

        var currentY = middlePoint
        let remainingX = Int(horizontalBlocks)
        var remainingY = -1
        var buildingNumber = 1
        
        for _ in stride(from: currentY, to: frame.minY + heightGap, by: -tileSize) {
            remainingY += 1
        }
        
        var pointerX = 0
        var pointerY = 0
        
        while ((remainingX - pointerX) > 1) {
            var highX = 0
            pointerY = 0
            currentY = middlePoint
            while((remainingY - pointerY) > 2) {
                let randomBuilding = getDimensionsOfRandomBuilding()
                placeBuildings(dimesions: randomBuilding, x: (tileSize * CGFloat(pointerX) + 25), y: currentY - (tileSize * CGFloat(pointerY)), down: true, buildingNumber: buildingNumber)
                buildingNumber += 1
                if randomBuilding.widthMultiplier > highX {
                    highX = randomBuilding.widthMultiplier
                }
                pointerY += randomBuilding.heightMultiplier
            }
            pointerX += highX
        }
        
        communication?.updateStats(current: GameInformation(appartments: appartment, bank: banks, hospital: hospital, house2: house2, libriary: library, post_office: post_office, school: school, shop: shop, town_hall: town_hall, tree: naturalElements), progressUpdata: false)
    }
    
    func placeBuildings(dimesions: BuildingDimension, x: CGFloat, y: CGFloat, down: Bool, buildingNumber: Int) {
        
        let width = dimesions.widthMultiplier
        let height = dimesions.heightMultiplier
        
        let building = SKSpriteNode(imageNamed: dimesions.name)
        building.name = dimesions.name
        if down {
            building.anchorPoint = CGPoint(x: 0, y: 1)
        } else {
            building.anchorPoint = CGPoint(x: 0, y: 0)
        }
        building.zPosition = 3
        building.size = CGSize(width: tileSize * CGFloat(width), height: tileSize * CGFloat(height))
        building.alpha = 0.0
        building.position = CGPoint(x: x, y: y + 20)
        
        //        building.physicsBody = SKPhysicsBody(texture: SKTexture(imageNamed: dimesions.name), size: CGSize(width: tileSize * CGFloat(width), height: tileSize * CGFloat(height)))
        //        building.physicsBody?.isDynamic = false
        
        let moveAction = SKAction.moveTo(y: y, duration: 0.2)
        let fadeAction = SKAction.fadeIn(withDuration: 0.2)
        let group = SKAction.group([moveAction, fadeAction])
        let sequence = SKAction.sequence([SKAction.wait(forDuration: Double(buildingNumber) * 0.1), group])
        building.run(sequence)
        addChild(building)
    }
    
    func getDimensionsOfRandomBuilding() -> BuildingDimension {
        
        let allBuildings: [SpriteNames] = [.appartment, .bank, .hospital, .house2, .library, .post_office, .school, .shop, .town_hall]
        let name = allBuildings.randomElement()!
        
        switch name {
        case .bank:
            banks += 1
            return BuildingDimension(widthMultiplier: 3, heightMultiplier: 2, name: name.rawValue)
        case .appartment:
            appartment += 1
            return BuildingDimension(widthMultiplier: 3, heightMultiplier: 3, name: name.rawValue)
        case .hospital:
            hospital += 1
            return BuildingDimension(widthMultiplier: 3, heightMultiplier: 3, name: name.rawValue)
        case .house2:
            house2 += 1
            return BuildingDimension(widthMultiplier: 2, heightMultiplier: 2, name: name.rawValue)
        case .library:
            library += 1
            return BuildingDimension(widthMultiplier: 3, heightMultiplier: 3, name: name.rawValue)
        case .post_office:
            post_office += 1
            return BuildingDimension(widthMultiplier: 2, heightMultiplier: 2, name: name.rawValue)
        case .school:
            school += 1
            return BuildingDimension(widthMultiplier: 3, heightMultiplier: 3, name: name.rawValue)
        case .shop:
            shop += 1
            return BuildingDimension(widthMultiplier: 2, heightMultiplier: 2, name: name.rawValue)
        case .town_hall:
            town_hall += 1
            return BuildingDimension(widthMultiplier: 3, heightMultiplier: 3, name: name.rawValue)
        }
    }
    
    func placeCar() {
        
        let _car = ["car1", "car2", "car3", "car4", "car5", "car6"].randomElement()!
        let car = SKSpriteNode(imageNamed: _car)
        car.name = "car"
        car.size = CGSize(width: tileSize / 2, height: tileSize / 2)
        car.zPosition = 2
        car.zRotation = CGFloat.pi / 2
        car.position = CGPoint(x: frame.maxX + 20, y: middlePoint + (tileSize / 4))
        car.physicsBody = SKPhysicsBody(texture: SKTexture(imageNamed: _car), size: CGSize(width: tileSize / 2, height: tileSize / 2))
        car.physicsBody?.affectedByGravity = false
        car.physicsBody?.allowsRotation = false
        
        let carMoveAction = SKAction.moveTo(x: frame.minX - 20, duration: 10)
        
        car.run(SKAction.sequence([SKAction.wait(forDuration: TimeInterval.random(in: 0.6 ... 1.5)), carMoveAction, SKAction.removeFromParent()]))
        numberOfCars += 1
        
        addChild(car)
    }
    
    func placeCar2() {
        
        let _car = ["car1", "car2", "car3", "car4", "car5", "car6"].randomElement()!
        let car2 = SKSpriteNode(imageNamed: _car)
        car2.name = "car"
        car2.size = CGSize(width: tileSize / 2, height: tileSize / 2)
        car2.zPosition = 2
        car2.zRotation = -CGFloat.pi / 2
        car2.position = CGPoint(x: frame.minX - 20, y: (middlePoint + tileSize) - (tileSize / 4))
        car2.physicsBody = SKPhysicsBody(texture: SKTexture(imageNamed: _car), size: CGSize(width: tileSize / 2, height: tileSize / 2))
        car2.physicsBody?.affectedByGravity = false
        car2.physicsBody?.allowsRotation = false
        car2.physicsBody?.friction = 0.5
        car2.physicsBody?.isDynamic = true
        
        let carMoveAction = SKAction.moveTo(x: frame.maxX + 20, duration: TimeInterval.random(in: 7...13))
        
        car2.run(SKAction.sequence([SKAction.wait(forDuration: TimeInterval.random(in: 0.1 ... 0.5)), carMoveAction, SKAction.removeFromParent()]))
        numberOfCars += 1
        
        addChild(car2)
    }
}

/*
 override func didMove(to view: SKView) {
 }
 
 
 func touchDown(atPoint pos : CGPoint) {
 }
 
 func touchMoved(toPoint pos : CGPoint) {
 }
 
 func touchUp(atPoint pos : CGPoint) {
 }
 
 override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
 }
 
 override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
 }
 
 override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
 }
 
 override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
 }
 */

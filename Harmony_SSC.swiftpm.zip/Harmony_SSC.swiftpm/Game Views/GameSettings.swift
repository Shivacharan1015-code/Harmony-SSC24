//
//  GameSettings.swift
//  Harmony_SSC
//
//  Created by Shivacharan Reddy on 24/02/24.
//

import SwiftUI

struct GameSettings: View {
    
    @Environment(\.dismiss) private var dismiss
    
    @State var easySelected: Bool = true
    @State var mediumSelected: Bool = false
    @State var hardSelected: Bool = false
    
    @State var hardness: CGFloat = 25.0
    @State var timelimit: Int = 75
    
    @State var offsetY: CGFloat = 0
    @State var offsetX: CGFloat = 0
    
    @State var index  = 0
    
    var images = ["one", "two", "three"]
    var information = ["You are in charge of this overly developed city. This city lacks natural environment. It is your job to replace some of the unuseful buildings with natural resources and bring back the balance in HARMONY", "Replace some of the duplicate buildings, ensure that in the least there are at least 1 or 2 of a type of building. Check the top right for parameters and dont go below them.", "Your goal is to get Harmony back to more than 50% while ensuring happinies and population are within the limits. Best of luck."]
    
    @State var backgroundColor1 = Color(.blue1)
    @State var backgroundColor2 = Color(.blue2)
    @State var backgroundColor3 = Color(.blue3)
    
    @State var textHeadingDark = Color(.blueHeading)
    @State var textHeadingLight = Color(.blueHeadingii)
    
    var body: some View {
        
        NavigationView(content: {
            
            ZStack {
                LinearGradient(colors: [backgroundColor1, backgroundColor2, backgroundColor3], startPoint: .leading, endPoint: .trailing)
                VStack {
                    ZStack {
                        
                        HStack {
                            Button {
                                dismiss()
                            } label: {
                                Circle()
                                    .frame(width: 55)
                                    .foregroundColor(textHeadingDark)
                                    .overlay {
                                        Image(systemName: "chevron.left")
                                            .tint(backgroundColor3)
                                    }
                            }
                            
                            Spacer()
                        }
//                        .frame(alignment: .leading)
                        .padding()
                        
                        Spacer()
                        
                        Text("Harmony The Game")
                            .lineLimit(2)
                            .multilineTextAlignment(.center)
                            .font(.system(size: 60, weight: .bold, design: .default))
                            .foregroundStyle(LinearGradient(colors: [textHeadingLight, textHeadingDark], startPoint: .leading, endPoint: .trailing))
                            .padding()
                        
                        Spacer()
                        
                    }
    //                .background(.blue)
                    
                    HStack {
                        Rectangle()
                            .foregroundColor(backgroundColor2)
                            .clipShape(RoundedRectangle(cornerRadius: 10))
                            .overlay {
                                VStack {
                                    
                                    HStack {
                                        
                                        Button {
                                            if index > 0 {
                                                index -= 1
                                            }
                                        } label: {
                                            Circle()
                                                .frame(width: 50)
                                                .foregroundColor(textHeadingDark)
                                                .overlay {
                                                    Image(systemName: "chevron.left")
                                                        .tint(index == 0 ? .gray : backgroundColor3)
                                                }
                                        }
                                        .padding()

                                        
                                        Text(information[index])
                                            .font(.title2)
                                            .multilineTextAlignment(.center)
                                            .foregroundColor(.black)
                                        
                                        Button {
                                            if index < 2 {
                                                index += 1
                                            }
                                        } label: {
                                            Circle()
                                                .frame(width: 50)
                                                .foregroundColor(textHeadingDark)
                                                .overlay {
                                                    Image(systemName: "chevron.right")
                                                        .tint(index == 2 ? .gray : backgroundColor3)
                                                }
                                        }
                                        .padding()
                                    }
                                    .padding()
                                    
                                    Image(images[0])
                                        .resizable()
                                        .scaledToFit()
                                        .clipShape(RoundedRectangle(cornerRadius: 10))
                                }
                                .padding()
                                
                            }
                            .shadow(radius: 10)
                            .offset(x: offsetX, y: offsetY)
                            .animation(.spring(response: 0.7, dampingFraction: 0.6, blendDuration: 0.6), value: offsetX == .zero)
                            .gesture(
                                DragGesture(minimumDistance: 2)
                                    .onChanged(onChanged(value:))
                                    .onEnded(onEnded(value:))
                            )
                        
                        VStack {
                            Button(action: {
                                easySelected = true
                                mediumSelected = false
                                hardSelected = false
                                hardness = 25.0
                                timelimit = 75
                                
                                withAnimation {
                                    backgroundColor1 = Color(.blue1)
                                    backgroundColor2 = Color(.blue2)
                                    backgroundColor3 = Color(.blue3)
                                    
                                    textHeadingDark = Color(.blueHeading)
                                    textHeadingLight = Color(.blueHeadingii)
                                }
                                
                            }, label: {
                                Text("Easy")
                                    .font(.system(size: 40, weight: .semibold, design: .default))
                                    .foregroundStyle(easySelected ? textHeadingDark : backgroundColor3)
                                    .background {
                                        RoundedRectangle(cornerRadius: 10)
                                            .fill(easySelected ? backgroundColor1 : textHeadingDark)
                                            .frame(width: 225, height: 75)
                                            .shadow(radius: 7)
                                            
                                    }
                                    .frame(width: 225, height: 75)
                                    
                            })
                            .padding([.leading, .trailing, .bottom])
                            
                            Button(action: {
                                easySelected = false
                                mediumSelected = true
                                hardSelected = false
                                hardness = 31.0
                                timelimit = 100
                                
                                withAnimation {
                                    backgroundColor1 = Color(.green1)
                                    backgroundColor2 = Color(.green2)
                                    backgroundColor3 = Color(.green3)
                                    
                                    textHeadingDark = Color(.greenHeading)
                                    textHeadingLight = Color(.greenHeadingii)
                                }
                                
                            }, label: {
                                Text("Medium")
                                    .font(.system(size: 40, weight: .semibold, design: .default))
                                    .foregroundStyle(mediumSelected ? textHeadingDark : backgroundColor3)
                                    .background {
                                        RoundedRectangle(cornerRadius: 10)
                                            .fill(mediumSelected ? backgroundColor1 : textHeadingDark)
                                            .frame(width: 225, height: 75)
                                            .shadow(radius: 7)
                                            
                                    }
                                    .frame(width: 225, height: 75)
                                    
                            })
                                .padding()
                            
                            Button(action: {
                                easySelected = false
                                mediumSelected = false
                                hardSelected = true
                                hardness = 39.0
                                timelimit = 130
                                
                                withAnimation {
                                    backgroundColor1 = Color(.red1)
                                    backgroundColor2 = Color(.red2)
                                    backgroundColor3 = Color(.red3)
                                    
                                    textHeadingDark = Color(.redHeading)
                                    textHeadingLight = Color(.redHeadingii)
                                }
                                
                            }, label: {
                                Text("Hard")
                                    .font(.system(size: 40, weight: .semibold, design: .default))
                                    .foregroundStyle(hardSelected ? textHeadingDark : backgroundColor3)
                                    .background {
                                        RoundedRectangle(cornerRadius: 10)
                                            .fill(hardSelected ? backgroundColor1 : textHeadingDark)
                                            .frame(width: 225, height: 75)
                                            .shadow(radius: 7)
                                            
                                    }
                                    .frame(width: 225, height: 75)
                                    
                            })
                                .padding()
                            
                            Spacer()
                            
                            NavigationLink(destination: GameView(timeLimit: timelimit, gameHardnes: hardness, minimumLimit: hardness < 30.0 ? 1 : 2)) {
                                Text("Play")
                                    .font(.system(size: 40, weight: .semibold, design: .default))
                                    .foregroundStyle(backgroundColor3)
                                    .background {
                                        RoundedRectangle(cornerRadius: 10)
                                            .fill(textHeadingDark)
                                            .frame(width: 225, height: 75)
                                            .shadow(radius: 7)
                                    }
                                    .frame(width: 225, height: 75)
                            }
                            
                            Spacer()
                        }
                    }
                    
                }
                .padding()
            }
        })
        .navigationTitle("Game")
        .navigationBarHidden(true)
        .navigationViewStyle(StackNavigationViewStyle())
        .statusBarHidden()
    }
    
    func onChanged(value: DragGesture.Value) {
        offsetY = value.translation.height
        offsetX = value.translation.width
    }
    
    func onEnded(value: DragGesture.Value) {
        offsetX = .zero
        offsetY = .zero
    }
}

struct HowToPlayInstructions: View {
    
    @State var offsetY: CGFloat = 0
    @State var offsetX: CGFloat = 0
    
    @State var index  = 0
    
    var images = ["one", "two", "three"]
    var information = ["You are in charge of this overly developed city. This city lacks natural environment. It is your job to replace some of the unuseful buildings with natural resources and bring back the balance in HARMONY", "Replace some of the duplicate buildings, ensure that in the least there are at least 1 or 2 of a type of building. Check the top right for parameters and dont go below them.", "Your goal is to get Harmony back to more than 50% while ensuring happinies and population are within the limits. Best of luck."]
    
    var body: some View {
        Rectangle()
            .foregroundColor(Color(.blue2))
            .clipShape(RoundedRectangle(cornerRadius: 10))
            .overlay {
                VStack {
                    
                    HStack {
                        
                        Button {
                            if index > 0 {
                                index -= 1
                            }
                        } label: {
                            Circle()
                                .frame(width: 50)
                                .foregroundColor(Color(.blueHeading))
                                .overlay {
                                    Image(systemName: "chevron.left")
                                        .tint(index == 0 ? .gray : Color(.blue3))
                                }
                        }
                        .padding()

                        
                        Text(information[index])
                            .font(.title2)
                            .multilineTextAlignment(.center)
                            .foregroundColor(.black)
                        
                        Button {
                            if index < 2 {
                                index += 1
                            }
                        } label: {
                            Circle()
                                .frame(width: 50)
                                .foregroundColor(Color(.blueHeading))
                                .overlay {
                                    Image(systemName: "chevron.right")
                                        .tint(index == 2 ? .gray : Color(.blue3))
                                }
                        }
                        .padding()
                    }
                    .padding()
                    
                    Image(images[0])
                        .resizable()
                        .scaledToFit()
                        .clipShape(RoundedRectangle(cornerRadius: 10))
                }
                .padding()
                
            }
            .shadow(radius: 10)
            .offset(x: offsetX, y: offsetY)
            .animation(.spring(response: 0.7, dampingFraction: 0.6, blendDuration: 0.6), value: offsetX == .zero)
            .gesture(
                DragGesture(minimumDistance: 2)
                    .onChanged(onChanged(value:))
                    .onEnded(onEnded(value:))
            )
    }
    
    func onChanged(value: DragGesture.Value) {
        offsetY = value.translation.height
        offsetX = value.translation.width
    }
    
    func onEnded(value: DragGesture.Value) {
        offsetX = .zero
        offsetY = .zero
    }
}

#Preview {
    GameSettings()
}

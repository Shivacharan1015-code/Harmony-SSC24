//
//  GameCompleteView.swift
//  Harmony_SSC
//
//  Created by Shivacharan Reddy on 25/02/24.
//

import SwiftUI

struct GameCompleteView: View {
    
    @Environment(\.dismiss) private var dismiss
    
    @Binding var gameResult: Bool
    @State var population: Int
    @State var happines: Int
    @State var harmony: Int
    @Binding var reasonForLoss: String
    @Binding var timeTaken: Int
    @Binding var gameMode: Int
    
    let congragulationsMessage = "Congrats, you have succesfully managed to complete the game.\nThere is no greater joy than being in the lap of our Mother Earth. The change starts with you, together let's make our environment more safe\n\nModern development is crucial but we must not forget what gives us life"
    
    let losingMessage = "You weren't able to complete the game. Better luck next time.\nWe don't have forever to save our planet, you have to be the change. It's now or never.\n\nWhile modern development is crucial, we must not forget what gives us life"
    
    var body: some View {
        ZStack {
            LinearGradient(colors: gameResult ? [Color(.red1), Color(.blue2), Color(.blue3)] : [Color(.blue1), Color(.red2), Color(.red3)], startPoint: .leading, endPoint: .trailing)
            VStack {
                Spacer()
                Text(gameResult ? "Objective Complete" : "Mision Failed")
                    .font(.system(size: 60, weight: .bold, design: .default))
                    .foregroundStyle(LinearGradient(colors: gameResult ? [Color(.blueHeadingii), Color(.blueHeading)] : [Color(.redHeadingii), Color(.redHeading)], startPoint: .leading, endPoint: .trailing))
                    .padding()
                
                Text(gameResult ? congragulationsMessage : losingMessage)
                    .multilineTextAlignment(.center)
                    .font(.title2)
                    .italic()
                    .foregroundStyle(.black)
                    .padding()
                
                Text(getReasonForLoss())
                    .multilineTextAlignment(.center)
                    .font(.title2)
                    .monospaced()
                    .foregroundStyle(.black)
                    .padding()
                
                Text("STATS")
                    .font(.title)
                    .foregroundStyle(.black)
                    .bold()
                
                Text("Population: \(population)")
                    .font(.title3)
                    .foregroundStyle(.black)
                Text("Happiness: \(happines)%")
                    .font(.title3)
                    .foregroundStyle(.black)
                Text("Harmony: \(harmony)%")
                    .font(.title3)
                    .foregroundStyle(.black)
                Text("Time Taken: \(timeTaken) seconds \(checkForHighScore())")
                    .font(.title3)
                    .foregroundStyle(.black)
                
                Spacer()
                
                Button {
                    dismiss()
                } label: {
                    Text("Done")
                        .font(.system(size: 40, weight: .semibold, design: .default))
                        .foregroundStyle(gameResult ? Color(.blue3) : Color(.red3))
                        .background {
                            RoundedRectangle(cornerRadius: 10)
                                .fill(gameResult ? Color(.blueHeading) : Color(.redHeading))
                                .frame(width: 225, height: 75)
                            
                        }
                        .frame(width: 225, height: 75)
                        .padding()
                }

                Spacer()
                
            }
            .padding()
        }
        .ignoresSafeArea()
        .navigationBarHidden(true)
        .navigationTitle("Result")
        .statusBarHidden()
    }
    
    func getReasonForLoss() -> String {
        
        print(#function)
        print(reasonForLoss)
        switch reasonForLoss {
        case "population":
            return "You reduced housing capacity by half or more, without people a community cannot thrive."
        case "happy":
            return "Your city's happinies fell below 50%, a city cannot be successful without mental well being"
        case "time":
            return "You ran out of time to save the city."
        default:
            return ""
        }
    }
    
    func checkForHighScore() -> String {
        
        if gameResult == false {
            return ""
        }
        
        if gameMode == 75 {
            var curentRecord = UserDefaults.standard.integer(forKey: "easy")
            if curentRecord == 0 {
                curentRecord = 999
            }
            if timeTaken < curentRecord {
                UserDefaults.standard.set(timeTaken, forKey: "easy")
                return "(New Record)"
            }
        } else if gameMode == 100 {
            var curentRecord = UserDefaults.standard.integer(forKey: "medium")
            if curentRecord == 0 {
                curentRecord = 999
            }
            if timeTaken < curentRecord {
                UserDefaults.standard.set(timeTaken, forKey: "medium")
                return "(New Record)"
            }
        } else {
            var curentRecord = UserDefaults.standard.integer(forKey: "hard")
            if curentRecord == 0 {
                curentRecord = 999
            }
            if timeTaken < curentRecord {
                UserDefaults.standard.set(timeTaken, forKey: "hard")
                return "(New Record)"
            }
        }
        
        return ""
    }
}
//
//#Preview {
//    GameCompleteView(gameResult: $true, population: 290, happines: 76, harmony: 53, reasonForLoss: "")
//}

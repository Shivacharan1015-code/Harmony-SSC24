//
//  CreditScreen.swift
//  Harmony_SSC
//
//  Created by Shivacharan Reddy on 26/02/24.
//

import SwiftUI

struct CreditScreen: View {
    var body: some View {
        Form {
            ForEach(Credits.credits) { credit in
                HStack {
                    Text(credit.names)
                    Text(": \(credit.assetName)")
                        .bold()
                }
            }
        }
        .navigationTitle("Credits")
    }
}

#Preview {
    CreditScreen()
}

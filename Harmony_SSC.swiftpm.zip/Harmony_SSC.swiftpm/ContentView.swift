import SwiftUI
import SceneKit
import UIKit.UIColor
import AVKit

struct ContentView: View {
    
//    @State var audioPlayer: AVAudioPlayer!
//    let sound = Bundle.main.path(forResource: "paperback", ofType: "mp3")
    
    @State var playGameValid = false
    @State var index: Int = 0
    @State var offsetY: CGFloat = 0
    @State var offsetX: CGFloat = 0
    
    @State var backgroundColor1 = Color(.blue1)
    @State var backgroundColor2 = Color(.blue2)
    @State var backgroundColor3 = Color(.blue3)
    
    @State var textHeadingDark = Color(.blueHeading)
    @State var textHeadingLight = Color(.blueHeadingii)
    
    @State var colorIndex = 0
    
    @State var timer = Timer.publish(every: 15, on: .main, in: .common).autoconnect()
    
    var body: some View {
        NavigationView {
            ZStack {
                LinearGradient(colors: [backgroundColor1, backgroundColor2, backgroundColor3], startPoint: .leading, endPoint: .trailing)
                
                VStack {
                    Text("Harmony")
                        .font(.system(size: 60, weight: .bold, design: .default))
                        .foregroundStyle(LinearGradient(colors: [textHeadingLight, textHeadingDark], startPoint: .leading, endPoint: .trailing))
                        .padding()
                    
                    
                    HStack {
                        Spacer()
                        Interactive3DView(fileName: "earth.scn")
                            .offset(x: offsetX, y: offsetY)
                            .animation(.spring(response: 0.7, dampingFraction: 0.6, blendDuration: 0.6), value: offsetX == .zero)
                            .gesture(
                                DragGesture(minimumDistance: 2)
                                    .onChanged(onChanged(value:))
                                    .onEnded(onEnded(value:))
                            )
                        Spacer()
                        
                        VStack {
                            
                            NavigationLink(destination: CreditScreen(), label: {
                                Circle()
                                    .frame(width: 50)
                                    .foregroundColor(textHeadingDark)
                                    .overlay {
                                        Image(systemName: "heart.fill")
                                            .tint(backgroundColor3)
                                    }
                            })
                            .padding(.bottom, 25)
                            
                            NavigationLink(destination: InformationView(), label: {
                                Text("Discover")
                                    .font(.system(size: 40, weight: .semibold, design: .default))
                                    .foregroundStyle(backgroundColor3)
                                    .background {
                                        RoundedRectangle(cornerRadius: 10)
                                            .fill(textHeadingDark)
                                            .frame(width: 225, height: 75)
                                            .shadow(radius: 7)                                        
                                    }
                                    .frame(width: 225, height: 75)
                            })
                            .padding(.bottom, 25)
                            
                            NavigationLink(destination: GameSettings(), label: {
                                Text("Play Game")
                                    .font(.system(size: 40, weight: .semibold, design: .default))
                                    .foregroundStyle(backgroundColor3)
                                    .background {
                                        RoundedRectangle(cornerRadius: 10)
                                            .fill(textHeadingDark)
                                            .frame(width: 225, height: 75)
                                            .shadow(radius: 7)
                                    }
                                    .frame(width: 225, height: 75)
                            })
                            .padding(.bottom, 15)
                            
                            Text("Personal Best Score:\n\(getHighScores())")
                                .font(.system(size: 15))
                                .foregroundStyle(textHeadingDark)
                                .multilineTextAlignment(.center)
                        }
                        Spacer()
                    }
                    .padding()
                }
                .padding()
            }
            .onReceive(timer, perform: { _ in
                if colorIndex % 3 == 0 {
                    
                    withAnimation {
                        backgroundColor1 = Color(.blue1)
                        backgroundColor2 = Color(.blue2)
                        backgroundColor3 = Color(.blue3)
                        
                        textHeadingDark = Color(.blueHeading)
                        textHeadingLight = Color(.blueHeadingii)
                    }
                    
                } else if colorIndex % 3 == 1 {
                    
                    withAnimation {
                        backgroundColor1 = Color(.red1)
                        backgroundColor2 = Color(.red2)
                        backgroundColor3 = Color(.red3)
                        
                        textHeadingDark = Color(.redHeading)
                        textHeadingLight = Color(.redHeadingii)
                    }
                    
                } else {
                    
                    withAnimation {
                        backgroundColor1 = Color(.green1)
                        backgroundColor2 = Color(.green2)
                        backgroundColor3 = Color(.green3)
                        
                        textHeadingDark = Color(.greenHeading)
                        textHeadingLight = Color(.greenHeadingii)
                    }
                    
                }
                
                colorIndex += 1
            })
            .onAppear(perform: {
                timer = self.timer.upstream.autoconnect()
                
//                self.audioPlayer = try! AVAudioPlayer(contentsOf: URL(fileURLWithPath: sound!))
//                if !self.audioPlayer.isPlaying {
//                    self.audioPlayer.play()
//                }
            })
            .onDisappear(perform: {
                self.timer.upstream.connect().cancel()
            })
            .statusBarHidden()
        }
        .navigationViewStyle(StackNavigationViewStyle())
    }
    
    func onChanged(value: DragGesture.Value) {
        offsetY = value.translation.height
        offsetX = value.translation.width
    }
    
    func onEnded(value: DragGesture.Value) {
        offsetX = .zero
        offsetY = .zero
    }
    
    func getHighScores() -> String {
        var highScore = ""
        let easyScore = UserDefaults.standard.integer(forKey: "easy")
        let meduimScore = UserDefaults.standard.integer(forKey: "medium")
        let hardScore = UserDefaults.standard.integer(forKey: "hard")
        
        if easyScore != 0 {
            highScore += "Easy - \(easyScore)"
        }
        if meduimScore != 0 {
            highScore += "\nMeduim - \(meduimScore)"
        }
        if hardScore != 0 {
            highScore += "\nHard - \(hardScore)"
        }
        
        if highScore != "" {
            highScore += "\n\nThe Lower the better"
        }
        
        return highScore
    }
}

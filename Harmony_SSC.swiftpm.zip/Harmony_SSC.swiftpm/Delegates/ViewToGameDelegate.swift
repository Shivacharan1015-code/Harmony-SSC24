//
//  ViewToGameDelegate.swift
//  Harmony_SSC
//
//  Created by Shivacharan Reddy on 24/02/24.
//

import Foundation

class ViewToGameDelegate: ObservableObject {
  @Published var delete = false
  static var shared = ViewToGameDelegate()
}

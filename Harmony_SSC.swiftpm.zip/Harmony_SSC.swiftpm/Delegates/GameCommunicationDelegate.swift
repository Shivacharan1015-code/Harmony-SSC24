//
//  GameCommunicationDelegate.swift
//  Harmony_SSC
//
//  Created by Shivacharan Reddy on 24/02/24.
//

import Foundation
import SpriteKit

protocol GameCommunicationDelegate {
    
    func updateStats(current: GameInformation, progressUpdata: Bool) 
    func selectedNode(name: String)
}

//
//  TimerViewDelegate.swift
//  Harmony_SSC
//
//  Created by Shivacharan Reddy on 25/02/24.
//

import Foundation

protocol TimerViewDelegate {
    func updateTime(timePassed: Int)
    func timeOver()
}

protocol InformationCardDelegate {
    func newIndex(index: Int)
}

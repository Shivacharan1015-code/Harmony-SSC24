//
//  File.swift
//  
//
//  Created by Shivacharan Reddy on 24/02/24.
//

import SwiftUI

struct GameInformation: Equatable {
    
    let appartments: Int
    let bank: Int
    let hospital: Int
    let house2: Int
    let libriary: Int
    let post_office: Int
    let school: Int
    let shop: Int
    let town_hall: Int
    let tree: Int
}

//
//  File.swift
//  
//
//  Created by Shivacharan Reddy on 26/02/24.
//

import SwiftUI

struct Credits: Identifiable {
    
    let id = UUID().uuidString
    let names: String
    let assetName: String
    
    static let credits: [Credits] = [
        Credits(names: "Earth 3D Model", assetName: "NASA"),
        Credits(names: "Tree Image", assetName: "Irina Iriser"),
        Credits(names: "Soil Image", assetName: "Glen Carrie"),
        Credits(names: "Water Image", assetName: "Akira Hojo"),
        Credits(names: "Fire Image", assetName: "Maxim Tajer"),
        Credits(names: "Deforestation Image", assetName: "Karsten Winegeart"),
        Credits(names: "Pollution Image", assetName: "Chris LeBoutillier"),
        Credits(names: "Plastic pollution Image", assetName: "Antoine GIRET"),
        Credits(names: "E-Waste Image", assetName: "John Cameron"),
        Credits(names: "Reuse Image", assetName: "Sigmund"),
        Credits(names: "Solor Image", assetName: "American Public Power Association"),
        Credits(names: "Bicycle Image", assetName: "Ilya Ilford"),
        Credits(names: "Tree sapling Image", assetName: "Noah Buscher"),
        Credits(names: "Game Assets", assetName: "All the Game Assets used are free for non-comercial projects and im compliance with the legal requirments"),
        Credits(names: "Main Music", assetName: "Music by: https://www.bensound.com/free-music-for-videos License code: RQRRTDSNBZZNUFSY")
    ]
}

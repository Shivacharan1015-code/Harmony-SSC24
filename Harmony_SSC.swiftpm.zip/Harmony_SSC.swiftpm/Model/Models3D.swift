//
//  File.swift
//  
//
//  Created by Shivacharan Reddy on 24/02/24.
//

import SwiftUI

struct Models3D: Identifiable {
    var id: String = UUID().uuidString
    var fileName: String
}
